﻿namespace StrategyGame.Base.Interfaces
{
    public interface IUnit
    {
        int Health { get; set; }
    }
}
