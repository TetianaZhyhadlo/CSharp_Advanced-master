﻿namespace ITEA_Collections.Base
{
    public interface IPerson
    {
        string Name { get; set; }
        int Age { get; set; }
    }
}
